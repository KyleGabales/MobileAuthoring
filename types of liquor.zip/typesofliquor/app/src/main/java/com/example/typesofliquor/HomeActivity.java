package com.example.typesofliquor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button but1=(Button) findViewById(R.id.buttonVodka);
        Button but2=(Button) findViewById(R.id.buttonWhiskey);
        Button but3=(Button) findViewById(R.id.buttonRum);
        Button but4=(Button) findViewById(R.id.buttonTequila);
        Button but5=(Button) findViewById(R.id.buttonGin);
        Button but6=(Button) findViewById(R.id.buttonBrandy);


        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int1=new Intent(HomeActivity.this,vodkaButton.class);
                startActivity(int1);
            }
        });

        but2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int2=new Intent(HomeActivity.this,whiskeyButton.class);
                startActivity(int2);
            }
        });

        but3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int3=new Intent(HomeActivity.this,rumButton.class);
                startActivity(int3);
            }
        });

        but4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int4=new Intent(HomeActivity.this,tequilaButton.class);
                startActivity(int4);
            }
        });

        but5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int5=new Intent(HomeActivity.this,ginButton.class);
                startActivity(int5);
            }
        });

        but6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent int6=new Intent(HomeActivity.this,brandyButton.class);
                startActivity(int6);
            }
        });

    }
}